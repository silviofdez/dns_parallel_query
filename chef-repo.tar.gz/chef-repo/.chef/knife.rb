cookbook_path [ '/root/chef-repo/cookbooks' ]
