#
# Cookbook Name:: parallelDnsQuery
# Recipe:: default
#
# Copyright 2015, Silvio Fernandez Marin
#
# All rights reserved - Do Not Redistribute
#

include_recipe "python"

python_pip "dnspython" do
  action :install
end

dns_par_que = Chef::Config[:file_cache_path] + "/dns_par_que.py"
query = Chef::Config[:file_cache_path] + "/query.txt"


remote_file dns_par_que do
  source "https://github.com/silviofdez/dns_parallel_query/raw/master/paralell_dns_queries.py"
  mode '755'
end

remote_file query do
  source "https://github.com/silviofdez/dns_parallel_query/raw/master/query.txt"
  mode '644'
end

execute "parallelDnsQueyr" do
  command dns_par_que
end