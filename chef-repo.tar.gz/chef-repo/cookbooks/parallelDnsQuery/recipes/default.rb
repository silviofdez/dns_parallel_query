#
# Cookbook Name:: parallelDnsQuery
# Recipe:: default
#
# Copyright 2015, Silvio Fernandez Marin
#
# All rights reserved - Do Not Redistribute
#

include_recipe "python"

python_pip "dnspython" do
  action :install
end

dns_par_que = "/root/dns_par_que.py"

remote_file dns_par_que do
  source "https://github.com/silviofdez/dns_parallel_query/raw/master/paralell_dns_queries.py"
  mode "0644"
end