#
# Cookbook Name:: parallelDnsQuery
# Recipe:: default
#
# Copyright 2015, Silvio Fernandez Marin
#
# All rights reserved - Do Not Redistribute
#

include_recipe "python"

python_pip "dnspython" do
  action :install
end

dns_par_que = Chef::Config[:file_cache_path] + "/dns_par_que.py"
query = Chef::Config[:file_cache_path] + "/query.txt"
query_result = Chef::Config[:file_cache_path] + "/query_results.txt"


remote_file dns_par_que do
  source "https://github.com/silviofdez/dns_parallel_query/raw/master/paralell_dns_queries.py"
  owner 'root'
  group 'root'
  mode '755'
end

remote_file query do
  source "https://github.com/silviofdez/dns_parallel_query/raw/master/query.txt"
  owner 'root'
  group 'root'
  mode '644'
end

execute "parallelDnsQuery" do
  command "python " +dns_par_que
end