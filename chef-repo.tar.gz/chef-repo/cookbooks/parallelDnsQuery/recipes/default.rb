#
# Cookbook Name:: parallelDnsQuery
# Recipe:: default
#
# Copyright 2015, Silvio Fernandez Marin
#
# All rights reserved - Do Not Redistribute
#

include_recipe "python"

python_pip "dnspython" do
  action :install
end

dns_par_que = node["dns_par_que"]["path"] + "/dns_par_que.py"
query = node["dns_par_que"]["path"] + "/query.txt"
query_result = node["dns_par_que"]["path"] + "/query_results.txt"


directory node["dns_par_que"]["path"] do
  owner "root"
  group "root"
  mode "0755"
  action :create
  recursive true
end

remote_file dns_par_que do
  source "https://github.com/silviofdez/dns_parallel_query/raw/master/paralell_dns_queries.py"
  owner 'root'
  group 'root'
  mode '755'
end

remote_file query do
  source "https://github.com/silviofdez/dns_parallel_query/raw/master/query.txt"
  owner 'root'
  group 'root'
  mode '644'
end

execute "parallelDnsQuery" do
  command "python " +dns_par_que
end